#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""PvZ-Portable 完整版 · 一键向导

一条命令把「开源引擎」变成「完整版」：
  1. 从官方 GitHub Releases 取对应平台的预编译程序
  2. 自动找到你已购买的正版 GOTY 的 main.pak + properties/
  3. 放到正确位置（Android / 网页版自动打包成导入用 ZIP）
  4. 逐项体检植物、僵尸、原版音乐与音效是否齐全
  5. 直接启动

本脚本只搬运你自己机器上的正版文件，不下载、不内嵌、不分发任何游戏素材。

用法：
    python 一键完整版.py                 # 全自动
    python 一键完整版.py --resdir D:\\PVZ  # 手动指定正版安装目录
    python 一键完整版.py --platform android
    python 一键完整版.py --check-only     # 只体检，不下载不启动
    python 一键完整版.py --demo           # 合成样本自测全流程（不联网）
"""
import argparse
import glob
import io
import json
import os
import platform
import shutil
import struct
import subprocess
import sys
import urllib.request
import zipfile
from collections import Counter

ROOT = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(ROOT, "bin")
ASSETS = os.path.join(ROOT, "assets")
REPO = "wszqkzqk/PvZ-Portable"
API = f"https://api.github.com/repos/{REPO}/releases/latest"

MAGIC = 0xBAC04AC0
XOR = 0xF7
FLAG_END = 0x80
KEY_MUSIC = ["sounds/mainmusic.mo3", "sounds/ZombiesOnYourLawn.ogg"]
CATEGORY = {
    ".png": "图像", ".jpg": "图像", ".jpeg": "图像", ".gif": "图像",
    ".reanim": "动画", ".xml": "配置/粒子", ".particle": "配置/粒子",
    ".ogg": "音效/音乐", ".mo3": "音效/音乐", ".wav": "音效/音乐",
    ".txt": "文本", ".ttf": "字体",
}

# 各平台对应的官方预编译资产（按优先级）
PLATFORM_ASSETS = {
    "windows": ["pvz-portable-windows-msvc-x64-static.exe",
                "pvz-portable-windows-ucrt64-static.exe",
                "pvz-portable-windows-msvc-x86-static.exe"],
    "linux":   ["pvz-portable-linux-static-x86_64",
                "pvz-portable-archlinux-x86_64"],
    "macos":   ["pvz-portable-macos-aarch64.zip"],
    "android": ["pvz-portable-android-arm64-v8a.apk"],
    "wasm":    ["pvz-portable-wasm.zip"],
}


def log(tag, msg):
    print(f"[{tag}] {msg}", flush=True)


# ---------------------------------------------------------------- 资源体检
def parse_pak(path):
    """按引擎 PakInterface.cpp 的规则解析 main.pak，返回 [(文件名, 大小)]。"""
    with open(path, "rb") as f:
        data = bytes(b ^ XOR for b in f.read())
    if len(data) < 8:
        raise ValueError("文件过短")
    magic, version = struct.unpack_from("<II", data, 0)
    if magic != MAGIC:
        raise ValueError(f"魔数不匹配 0x{magic:08X}，可能不是 GOTY 版 main.pak")
    if version != 0:
        raise ValueError(f"pak 版本 {version} 不受支持")
    pos, out = 8, []
    while pos < len(data):
        flags = data[pos]
        pos += 1
        if flags & FLAG_END:
            break
        width = data[pos]
        pos += 1
        if pos + width + 12 > len(data):
            break
        name = data[pos:pos + width].decode("latin-1").replace("\\", "/")
        pos += width
        size = struct.unpack_from("<i", data, pos)[0]
        pos += 4 + 8
        out.append((name, size))
    return out


def health_check(folder, quiet=False):
    """体检资源目录，返回 (是否完整, 资源数)。"""
    pak = os.path.join(folder, "main.pak")
    props = os.path.join(folder, "properties")
    if not os.path.isfile(pak):
        if not quiet:
            log("缺", "没找到 main.pak")
        return False, 0
    try:
        names = parse_pak(pak)
    except Exception as e:
        if not quiet:
            log("错", f"main.pak 解析失败：{e}")
        return False, 0
    upper = {n.upper(): s for n, s in names}
    counter = Counter(
        CATEGORY.get(os.path.splitext(n)[1].lower(), "其他") for n, _ in names
    )
    if not quiet:
        total = sum(s for _, s in names) / 1024 / 1024
        log("全", f"main.pak：{len(names)} 个资源 / {total:.1f} MB")
        for k, v in counter.most_common():
            log("  ", f"{k:<10} {v:>5} 个")

    ok = True
    for key in KEY_MUSIC:
        hit = key.upper() in upper
        if not quiet:
            log("  ", f"{'✅' if hit else '❌'} 原版音乐 {key}")
        ok &= hit

    low = [n.lower() for n, _ in names]
    reanim = [n for n in low if n.endswith(".reanim")]
    # 原版 pak 里是 reanim/Peashooter.reanim、reanim/Zombie.reanim 这类命名，
    # 不带 "plant" 字样，故按具体角色名 + 动画总数判断。
    has_pea = any("peashooter" in n for n in reanim)
    has_zombie = any("zombie" in n for n in reanim)
    sounds = [n for n in low if n.startswith("sounds/")]
    if not quiet:
        log("  ", f"{'✅' if reanim else '❌'} 角色动画 {len(reanim)} 组"
                  f"（豌豆射手 {'有' if has_pea else '缺'} / 普通僵尸 {'有' if has_zombie else '缺'}）")
        log("  ", f"{'✅' if sounds else '⚠️ '} 音效/音乐 {len(sounds)} 个")
    ok &= len(reanim) >= 2 and has_pea and has_zombie and bool(sounds)

    if os.path.isdir(props):
        n = sum(len(f) for _, _, f in os.walk(props))
        if not quiet:
            log("  ", f"✅ properties/ 共 {n} 个文件")
    else:
        if not quiet:
            log("  ", "❌ 缺 properties/ 目录")
        ok = False
    return ok, len(names)


# ---------------------------------------------------------------- 步骤 1：程序
def detect_platform(explicit=None):
    if explicit:
        return explicit
    s = platform.system().lower()
    if s == "windows":
        return "windows"
    if s == "linux":
        return "linux"
    if s == "darwin":
        return "macos"
    return "windows"


def download_program(plat, skip=False):
    os.makedirs(BIN, exist_ok=True)
    existing = [f for f in os.listdir(BIN)
                if f != "pvz-resources.zip" and os.path.isfile(os.path.join(BIN, f)) and
                (f.lower().endswith((".exe", ".apk", ".zip")) or
                 not os.path.splitext(f)[1])]
    if existing:
        log("1/5", f"程序已就位：{', '.join(existing[:3])}（跳过下载）")
        return os.path.join(BIN, existing[0])
    if skip:
        log("1/5", "跳过下载（--check-only）")
        return None

    log("1/5", "查询官方最新发行版…")
    req = urllib.request.Request(API, headers={"User-Agent": "pvz-complete-setup"})
    with urllib.request.urlopen(req, timeout=30) as r:
        rel = json.load(r)
    tag = rel["tag_name"]
    assets = {a["name"]: a for a in rel["assets"]}
    log("1/5", f"最新版 {tag}，共 {len(assets)} 个平台构建")
    chosen = next((n for n in PLATFORM_ASSETS[plat] if n in assets), None)
    if not chosen:
        raise RuntimeError(f"该平台没有可用构建，请手动到 GitHub Releases 下载："
                           f"https://github.com/{REPO}/releases/latest")
    url = assets[chosen]["browser_download_url"]
    size = assets[chosen]["size"] / 1024 / 1024
    dst = os.path.join(BIN, chosen)
    log("1/5", f"下载 {chosen}（{size:.1f} MB）…")
    with urllib.request.urlopen(urllib.request.Request(
            url, headers={"User-Agent": "pvz-complete-setup"}), timeout=600) as r, \
            open(dst, "wb") as f:
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            f.write(chunk)
    if chosen.endswith(".zip"):
        with zipfile.ZipFile(dst) as z:
            z.extractall(os.path.join(BIN, "wasm" if plat == "wasm" else "macos"))
        log("1/5", f"已解压到 bin/{'wasm' if plat == 'wasm' else 'macos'}/")
        return os.path.join(BIN, "wasm" if plat == "wasm" else "macos")
    if not chosen.endswith((".exe", ".apk")):
        os.chmod(dst, 0o755)
    log("1/5", f"完成：bin/{chosen}")
    return dst


# ---------------------------------------------------------------- 步骤 2：找素材
def search_candidates():
    home = os.path.expanduser("~")
    c = [ASSETS, BIN, ROOT, os.getcwd(),
         os.path.join(home, "Downloads"), os.path.join(home, "Desktop"),
         os.path.join(home, "下载"), os.path.join(home, "桌面")]
    if platform.system() == "Windows":
        for base in [os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                     os.environ.get("ProgramFiles", r"C:\Program Files"),
                     r"D:\SteamLibrary", r"E:\SteamLibrary"]:
            c += [os.path.join(base, "Steam", "steamapps", "common", "Plants vs Zombies"),
                  os.path.join(base, "Steam", "steamapps", "common", "Plants vs Zombies GOTY Edition"),
                  os.path.join(base, "PopCap Games", "Plants vs Zombies"),
                  os.path.join(base, "EA Games", "Plants vs Zombies")]
    elif platform.system() == "Darwin":
        c += [os.path.join(home, "Library", "Application Support", "Steam",
                           "steamapps", "common", "Plants vs Zombies")]
    else:
        c += [os.path.join(home, ".steam", "steam", "steamapps", "common", "Plants vs Zombies"),
              os.path.join(home, ".local", "share", "Steam", "steamapps",
                           "common", "Plants vs Zombies"),
              os.path.join(home, ".wine", "drive_c", "Program Files (x86)",
                           "Steam", "steamapps", "common", "Plants vs Zombies")]
    return c


def find_resources(explicit=None):
    roots = ([explicit] if explicit else []) + search_candidates()
    hits = []
    for root in roots:
        if not root or not os.path.isdir(root):
            continue
        pak = os.path.join(root, "main.pak")
        props = os.path.join(root, "properties")
        if os.path.isfile(pak) and os.path.isdir(props):
            ok, n = health_check(root, quiet=True)
            if ok:
                hits.append((root, n))
    # 去重
    seen, uniq = set(), []
    for r, n in hits:
        k = os.path.realpath(r)
        if k not in seen:
            seen.add(k)
            uniq.append((r, n))
    return uniq


# ---------------------------------------------------------------- 步骤 3：放置
def place_resources(src, plat):
    os.makedirs(BIN, exist_ok=True)
    if plat in ("windows", "linux", "macos"):
        # 用 copyfile 而非 copy2：部分受限文件系统不允许改时间戳
        pak_src, pak_dst = os.path.join(src, "main.pak"), os.path.join(BIN, "main.pak")
        if os.path.abspath(pak_src) != os.path.abspath(pak_dst):
            shutil.copyfile(pak_src, pak_dst)
        props_src, props_dst = os.path.join(src, "properties"), os.path.join(BIN, "properties")
        if os.path.abspath(props_src) != os.path.abspath(props_dst):
            if os.path.exists(props_dst):
                shutil.rmtree(props_dst)
            os.makedirs(props_dst, exist_ok=True)
            for r, _, fs in os.walk(props_src):
                rel = os.path.relpath(r, props_src)
                out = props_dst if rel == "." else os.path.join(props_dst, rel)
                os.makedirs(out, exist_ok=True)
                for f in fs:
                    shutil.copyfile(os.path.join(r, f), os.path.join(out, f))
        log("3/5", f"已放到 bin/（{src} → 程序目录）")
        return BIN
    # Android / WASM：官方导入界面接受 ZIP
    zpath = os.path.join(BIN, "pvz-resources.zip")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        z.write(os.path.join(src, "main.pak"), "main.pak")
        for r, _, fs in os.walk(os.path.join(src, "properties")):
            for f in fs:
                p = os.path.join(r, f)
                z.write(p, os.path.join("properties", os.path.relpath(p, os.path.join(src, "properties"))))
    log("3/5", f"已生成导入包 bin/pvz-resources.zip（首次启动选它导入即可）")
    return BIN


# ---------------------------------------------------------------- 步骤 5：启动
def launch(plat, program):
    if plat == "android":
        apk = next((os.path.join(BIN, f) for f in os.listdir(BIN)
                    if f.endswith(".apk")), None)
        log("5/5", "Android：把 bin/ 里的 APK 传到手机安装，首次启动选择 "
                  "bin/pvz-resources.zip 导入资源即可。")
        return
    if plat == "wasm":
        w = os.path.join(BIN, "wasm")
        log("5/5", f"网页版：已在 {w} 起本地服务，浏览器打开 http://localhost:8000 "
                  "（手机与电脑同一 WiFi 时用电脑 IP 访问），页面里上传 pvz-resources.zip。")
        try:
            subprocess.Popen([sys.executable, "-m", "http.server", "8000"], cwd=w)
        except Exception as e:
            log("5/5", f"自动起服务失败（{e}），请手动在 {w} 执行 python -m http.server 8000")
        return
    if plat == "macos":
        log("5/5", "macOS：打开 bin/macos/ 中的 .app；资源放 ~/Library/Application Support/"
                  "io.github.wszqkzqk/PvZPortable/（或按弹窗提示路径）。")
        return
    if not program or not os.path.isfile(program):
        log("5/5", "没找到可执行文件，请检查步骤 1。")
        return
    if plat == "linux" and not os.access(program, os.X_OK):
        os.chmod(program, 0o755)
    log("5/5", f"启动 {os.path.basename(program)} …")
    try:
        subprocess.Popen([program], cwd=os.path.dirname(program))
        log("✅", "已启动。植物 / 僵尸 / 全部关卡 / 原版音乐音效都在你的正版资源里。")
    except Exception as e:
        log("错", f"启动失败：{e}；请手动双击 bin/ 里的程序运行。")


# ---------------------------------------------------------------- 主流程
def demo():
    """合成一个最小合法资源目录，离线验证「找 → 放 → 体检 → 打包」全流程。"""
    import tempfile
    entries = [("sounds/mainmusic.mo3", 1024),
               ("sounds/ZombiesOnYourLawn.ogg", 2048),
               ("sounds/plant.wav", 128),
               ("reanim/Plants/Peashooter.reanim", 256),
               ("reanim/Zombies/Zombie.reanim", 256)]
    body = bytearray()
    for n, s in entries:
        nb = n.encode("latin-1")
        body += bytes([0, len(nb)]) + nb + struct.pack("<i", s) + struct.pack("<q", 0)
    blob = bytes(b ^ XOR for b in (struct.pack("<II", MAGIC, 0) +
                                   bytes(body) + bytes([FLAG_END]) + b"\0" * 4096))
    with tempfile.TemporaryDirectory() as d:
        src = os.path.join(d, "正版游戏")
        os.makedirs(os.path.join(src, "properties"))
        open(os.path.join(src, "main.pak"), "wb").write(blob)
        open(os.path.join(src, "properties", "LawnStrings.txt"), "w").write("demo")
        log("demo", f"合成样本：{src}")
        ok, n = health_check(src)
        assert ok and n == len(entries), (ok, n)
        out = place_resources(src, "windows")
        ok2, _ = health_check(out)
        assert ok2
        place_resources(src, "android")
        zp = os.path.join(BIN, "pvz-resources.zip")
        with zipfile.ZipFile(zp) as z:
            names = z.namelist()
            assert "main.pak" in names and any(x.startswith("properties/") for x in names)
        log("demo", "全流程自测通过：体检 ✅ 桌面放置 ✅ 移动端导入包 ✅")
        # 清理 demo 产物，避免污染真实交付
        for p in (os.path.join(BIN, "main.pak"), os.path.join(BIN, "properties"), zp):
            if os.path.isfile(p):
                os.remove(p)
            elif os.path.isdir(p):
                shutil.rmtree(p)


def main():
    ap = argparse.ArgumentParser(description="PvZ-Portable 完整版一键向导")
    ap.add_argument("--platform", choices=list(PLATFORM_ASSETS), help="覆盖自动识别的平台")
    ap.add_argument("--resdir", help="正版 GOTY 安装目录（含 main.pak 和 properties/）")
    ap.add_argument("--check-only", action="store_true", help="只体检现有资源")
    ap.add_argument("--skip-download", action="store_true", help="不下载程序")
    ap.add_argument("--no-launch", action="store_true", help="做完不启动")
    ap.add_argument("--demo", action="store_true", help="离线自测全流程")
    args = ap.parse_args()

    if args.demo:
        demo()
        return

    plat = detect_platform(args.platform)
    log("0/5", f"平台：{plat}｜工作目录：{ROOT}")

    if args.check_only:
        ok, _ = health_check(health_dir(args.resdir))
        print("\n" + ("🎉 资源齐全，可以开玩。" if ok else "⚠️ 有缺项，按上面提示补齐。"))
        sys.exit(0 if ok else 1)

    program = None
    if not args.skip_download:
        try:
            program = download_program(plat)
        except Exception as e:
            log("1/5", f"自动下载失败：{e}")
            log("1/5", "请手动到 https://github.com/wszqkzqk/PvZ-Portable/releases/latest "
                      "下载对应平台文件放进 bin/，再重跑本脚本（会跳过下载）。")
            if not glob.glob(os.path.join(BIN, "*")):
                sys.exit(1)

    log("2/5", "搜索正版 GOTY 资源（main.pak + properties/）…")
    hits = find_resources(args.resdir)
    if not hits:
        print("""
没找到正版资源。请二选一：
  A. 重新运行并指定目录：python 一键完整版.py --resdir "你的PvZ安装目录"
  B. 把正版安装目录里的 main.pak 和 properties/ 一起复制到本包的 assets/ 目录

购买渠道：Steam《Plants vs. Zombies GOTY Edition》或 EA App。
本包不含任何游戏素材，也不会替你下载——这是版权底线。
""")
        sys.exit(1)
    src, n = hits[0]
    log("2/5", f"找到：{src}（{n} 个资源）" + (f"，另有 {len(hits)-1} 处候选" if len(hits) > 1 else ""))

    place_resources(src, plat)
    target = BIN if plat not in ("android", "wasm") else src
    log("4/5", "完整性体检：")
    ok, _ = health_check(target)
    if not ok:
        print("\n⚠️ 资源不完整：确认你导入的是《年度版 GOTY》完整安装目录，而不是试玩版或旧版。")
        sys.exit(1)
    print("\n🎉 体检通过：植物、僵尸、关卡素材、原版 MO3 音乐与音效全部齐全。")

    if not args.no_launch:
        launch(plat, program)
    else:
        log("5/5", "已跳过启动（--no-launch），可随时用 启动-Windows.bat / 启动-Linux.sh 运行。")


def health_dir(explicit=None):
    if explicit:
        return explicit
    for c in [BIN, ASSETS, ROOT]:
        if os.path.isfile(os.path.join(c, "main.pak")):
            return c
    return BIN


if __name__ == "__main__":
    main()
