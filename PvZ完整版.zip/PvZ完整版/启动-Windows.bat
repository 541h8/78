@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ============================================
echo   植物大战僵尸 完整版 (PvZ-Portable)
echo ============================================
echo.

if not exist "bin\main.pak" goto nores
if not exist "bin\properties" goto nores

set "EXE="
for %%f in (bin\pvz-portable-windows-*.exe) do set "EXE=%%~ff"
if not defined EXE goto noexe

echo 资源已就位，启动中...
start "" "%EXE%"
echo.
echo 若窗口没出现，看看是否有弹窗提示资源路径。
timeout /t 3 >nul
exit /b 0

:nores
echo [缺资源] bin 目录里没有 main.pak 或 properties\
echo.
echo 第一次使用请运行：  python 一键完整版.py
echo 它会自动下载程序、找到你已买的正版资源并放好。
echo 也可以手动把正版 GOTY 安装目录里的 main.pak 和 properties\
echo 一起复制到 bin\ 目录。
echo.
echo 购买：Steam 搜 "Plants vs. Zombies GOTY Edition"
pause
exit /b 1

:noexe
echo [缺程序] bin 目录里没有 pvz-portable-windows-*.exe
echo 运行：  python 一键完整版.py
echo 或手动到 https://github.com/wszqkzqk/PvZ-Portable/releases/latest 下载
pause
exit /b 1
