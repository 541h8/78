#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "============================================"
echo "  植物大战僵尸 完整版 (PvZ-Portable)"
echo "============================================"
echo

if [[ ! -f bin/main.pak || ! -d bin/properties ]]; then
    echo "[缺资源] bin/ 里没有 main.pak 或 properties/"
    echo "第一次使用请运行：  python3 一键完整版.py"
    echo "它会自动下载程序、找到你已买的正版资源并放好。"
    echo "购买：Steam 搜 \"Plants vs. Zombies GOTY Edition\""
    exit 1
fi

BIN=$(find bin -maxdepth 1 -type f -name 'pvz-portable*' \
      ! -name '*.exe' ! -name '*.apk' ! -name '*.zip' | head -1)
if [[ -z "$BIN" ]]; then
    echo "[缺程序] 运行：python3 一键完整版.py  或到 GitHub Releases 手动下载"
    exit 1
fi
chmod +x "$BIN"
echo "资源已就位，启动 $BIN …"
cd "$(dirname "$BIN")"
exec "./$(basename "$BIN")"
